import React from "react";

function Header() {
  return (
    <div className="header">
      <header>
        <h1>ShapeAI</h1>
      </header>
    </div>
  );
}

export default Header;
